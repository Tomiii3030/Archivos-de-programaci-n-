def saludar_nombre(nom):
    print(f"Hola {nom}")

nom= input("Ingrese su nombre: ")
saludar_nombre(nom)
num1= input("Ingrese el primer número: ")
num2 = input("Ingrese el segundo número: ")
sumar =(num1 , num2)
