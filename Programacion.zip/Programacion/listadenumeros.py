#                 0 1 2 3 4 5 
listadenumeros = [1,2,3,4,5,6] #lista

print(listadenumeros[0]) 
print(listadenumeros[-1]) 

n = len(listadenumeros)
print(listadenumeros[n-1]) 
