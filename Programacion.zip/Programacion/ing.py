Pizza = False
mensaje = "Pizza lista"
if Pizza == True:
    print("La pizza esta lista")
    elif Pizza == False:
 resp == input("Puede comprar la pizza? (si/no): ")
if  resp == "si":
    Pizza = True
    print(mensaje)
else:
    print("No puede comprar la pizza, vuelva mas tarde")
else:
    print("La pizza no esta lista, vuelva mas tarde")