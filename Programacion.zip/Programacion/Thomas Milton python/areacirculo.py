import math


math.pi
def area_circulo(radio):
    area = math.pi * (radio ** 2)
    return area
radio = int(input("Ingrese el valor del radio del círculo: "))
area = area_circulo(radio)
print(f"El área del círculo es: {area}")