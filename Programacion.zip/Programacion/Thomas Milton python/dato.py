s = "milton"
print(s)
print(len(s)) #cuenta la cantidad de letras de en este caso "milton"
print(s[0]) #imprime la letra en la posicion 0
