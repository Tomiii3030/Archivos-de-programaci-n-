num1 = int(input("digite la longitud en metros: "))
print("el resultado de la longitud en metros es", num1 * 100)
