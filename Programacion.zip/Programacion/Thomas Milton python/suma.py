print("digite dos numeros")
num1 = float(input("digite el primer numero: "))
num2 = int(input("digite el segundo numero: "))

suma = num1 + num2
print("la suma de los numeros es: " + (suma))