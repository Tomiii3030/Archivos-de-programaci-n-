print("hola mundo")
num = 5 #int es el numero entero
num = 5.0 #float es el numero decimal

saludo = "hola" #str
respuesta = True #bool
nombre =input("cual es tu nombre?") #str
print("hola"+ nombre) 
