base = int(input("ingrese la base del triangulo"))
altura = int(input("ingrese la altura del triangulo"))
area = (base * altura) / 2
print("el area del triangulo es: ", area)
