def saludar(nombre):
    print(f"hola {nombre} desde mi primera funcion")
   
    saludar("tomi")


