edad = int(input("cuantos años tienes? "))
print("su edad en 2030 sera: ", edad + 5)