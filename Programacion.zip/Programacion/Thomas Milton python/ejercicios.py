#declaro 2 variables con nombre a y b con valores numericos 
a = 5
b = 10

c = b
b = a 
a = c
print("el valor de a es: ", a)
print("el valor de b es: ", b)