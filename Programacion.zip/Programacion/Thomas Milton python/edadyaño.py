edad = int(input("cuantos años tienes? "))
año = int(input("en que año estamos? "))
print("usted nacio en el año: ", año - edad)
