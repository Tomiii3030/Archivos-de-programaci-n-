nombre = ("encender equipo: ")
tarea=("encender el monitor y la impresora")
estado = ("pendiente")
print(f"{nombre} revisando la tarea {tarea}")
if estado ==  "finalizado":
    print(f"el equipo esta {estado}, puede trabajar")
elif estado == "pendiente":
 print(f"{nombre} : {tarea} aun {estado} complete la tarea")